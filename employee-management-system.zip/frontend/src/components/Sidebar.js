
import React from "react";

function Sidebar(){
  return(
    <div style={{width:"200px",height:"100vh",background:"#343a40",color:"white",padding:"20px"}}>
      <h4>EMS Dashboard</h4>
      <p>Employees</p>
      <p>Add Employee</p>
    </div>
  );
}

export default Sidebar;
