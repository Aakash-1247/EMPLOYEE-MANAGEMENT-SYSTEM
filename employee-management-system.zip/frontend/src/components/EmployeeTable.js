
import React,{useEffect,useState} from "react";
import api from "../api";
import {Table,Button} from "react-bootstrap";

function EmployeeTable(){

  const [employees,setEmployees] = useState([]);

  const fetchEmployees = async()=>{
    const res = await api.get("/employees");
    setEmployees(res.data);
  }

  useEffect(()=>{
    fetchEmployees();
  },[]);

  const deleteEmployee = async(id)=>{
    await api.delete(`/employees/${id}`);
    fetchEmployees();
  }

  return(
    <Table striped bordered hover className="mt-4">
      <thead>
        <tr>
          <th>Name</th>
          <th>Role</th>
          <th>Salary</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
        {employees.map(emp=>(
          <tr key={emp._id}>
            <td>{emp.name}</td>
            <td>{emp.role}</td>
            <td>{emp.salary}</td>
            <td>
              <Button variant="danger" onClick={()=>deleteEmployee(emp._id)}>
                Delete
              </Button>
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}

export default EmployeeTable;
