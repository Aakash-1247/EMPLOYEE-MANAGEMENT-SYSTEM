
import React from "react";
import { Card } from "react-bootstrap";
import { FaUsers } from "react-icons/fa";

function Dashboard({count}){
  return(
    <Card className="p-4 shadow mb-4">
      <FaUsers size={40}/>
      <h3>{count}</h3>
      <p>Total Employees</p>
    </Card>
  );
}

export default Dashboard;
