
import React,{useState} from "react";
import api from "../api";
import {Form,Button,Card} from "react-bootstrap";

function AddEmployee({refresh}){

  const [employee,setEmployee] = useState({
    name:"",
    role:"",
    salary:""
  });

  const handleChange=(e)=>{
    setEmployee({...employee,[e.target.name]:e.target.value});
  }

  const handleSubmit=async(e)=>{
    e.preventDefault();

    if(!employee.name || !employee.role || !employee.salary){
      alert("All fields required");
      return;
    }

    await api.post("/employees",employee);

    setEmployee({name:"",role:"",salary:""});

    refresh();
  }

  return(
    <Card className="p-4 shadow">
      <h4>Add Employee</h4>

      <Form onSubmit={handleSubmit}>
        <Form.Control name="name" placeholder="Employee Name" value={employee.name} onChange={handleChange} className="mb-2"/>
        <Form.Control name="role" placeholder="Role" value={employee.role} onChange={handleChange} className="mb-2"/>
        <Form.Control name="salary" type="number" placeholder="Salary" value={employee.salary} onChange={handleChange} className="mb-2"/>
        <Button type="submit">Add</Button>
      </Form>
    </Card>
  );
}

export default AddEmployee;
