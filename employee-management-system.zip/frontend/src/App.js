
import React,{useState} from "react";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import AddEmployee from "./components/AddEmployee";
import EmployeeTable from "./components/EmployeeTable";

function App(){

  const [count,setCount] = useState(0);

  const refresh=()=>{
    window.location.reload();
  }

  return(
    <div style={{display:"flex"}}>

      <Sidebar/>

      <div style={{flex:1,padding:"20px"}}>
        <Dashboard count={count}/>
        <AddEmployee refresh={refresh}/>
        <EmployeeTable/>
      </div>

    </div>
  );
}

export default App;
